﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LookAtPositionControllor : MonoBehaviour {

    public SliderWithEcho X, Y, Z;
    private const float zoomSpeed = 10.0f;
    private const float Speed = 1.0f;
    public Camera myCamera = null;
    private Vector3 mPreviousSliderValues = Vector3.zero;
    float rotationX = 0F;
    float rotationY = 0F;
    public Transform LookAtPosition = null;

    Quaternion originalRotation;
    // Use this for initialization
    void Start()
    {
        X.SetSliderListener(XValueChanged);
        Y.SetSliderListener(YValueChanged);
        Z.SetSliderListener(ZValueChanged);
        X.SetSliderValue(0.0f);
        Y.SetSliderValue(0.0f);
        Z.SetSliderValue(0.0f);
        SetRange();
        originalRotation = myCamera.gameObject.transform.localRotation;
    }
    
    void Update()
    {

    }

    //---------------------------------------------------------------------------------
    // Initialize slider bars to specific function
    void SetRange()
    {
        Vector3 p = ReadObjectXfrom();
        mPreviousSliderValues = p;
        X.InitSliderRange(-30, 30, p.x);
        Y.InitSliderRange(-30, 30, p.y);
        Z.InitSliderRange(-30, 30, p.z);
        
    }
    //---------------------------------------------------------------------------------

    //---------------------------------------------------------------------------------
    // resopond to sldier bar value changes
    void XValueChanged(float v)
    {
        //change camera view
        //Vector3 p = ReadObjectXfrom();
        //// if not in rotation, next two lines of work would be wasted
        //float dx = v - mPreviousSliderValues.x;
        //mPreviousSliderValues.x = v;
        //myCamera.transform.LookAt(LookAtPosition);
        //myCamera.transform.RotateAround(LookAtPosition.localPosition, Vector3.up, v);
        ObjectSetUI();
    }

    void YValueChanged(float v)
    {
        //Vector3 p = ReadObjectXfrom();
        //// if not in rotation, next two lines of work would be wasted
        //float dy = v - mPreviousSliderValues.y;
        //mPreviousSliderValues.y = v;
        //Quaternion q = Quaternion.AngleAxis(dy, Vector3.up);
        //p.y = v;
        //myCamera.transform.LookAt(LookAtPosition);
        // myCamera.transform.RotateAround(LookAtPosition.localPosition, Vector3.up, v);
        ObjectSetUI();
    }

    void ZValueChanged(float v)
    {
        //Vector3 p = ReadObjectXfrom();
        //// if not in rotation, next two lines of work would be wasterd
        //float dz = v - mPreviousSliderValues.z;
        //mPreviousSliderValues.z = v;
        //Quaternion q = Quaternion.AngleAxis(dz, Vector3.forward);
        //p.z = v;
        //myCamera.transform.LookAt(LookAtPosition);
        //myCamera.transform.RotateAround(LookAtPosition.localPosition, Vector3.up, v);

        ObjectSetUI();
    }
    //---------------------------------------------------------------------------------

    public void ObjectSetUI()
    {
        Vector3 p = ReadObjectXfrom();
        X.TheEcho.text = (p.x).ToString("0.0000");
        Y.TheEcho.text = (p.y).ToString("0.0000");
        Z.TheEcho.text = (p.z).ToString("0.0000");

        LookAtPosition.localPosition = new Vector3(-p.x, -p.y, -p.z);
        myCamera.transform.LookAt(LookAtPosition);
    }

    private Vector3 ReadObjectXfrom()
    {
        Vector3 p = Vector3.zero;
        p.x = X.GetSliderValue();
        p.y = Y.GetSliderValue();
        p.z = Z.GetSliderValue();
        return p;
    }

    public void ReSet()
    {
        X.SetSliderValue(0.0f);
        Y.SetSliderValue(0.0f);
        Z.SetSliderValue(0.0f);
    }
}