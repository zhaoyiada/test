﻿using System; // for assert
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // for GUI elements: Button, Toggle
using UnityEngine.EventSystems;

public partial class MainController : MonoBehaviour
{
    GameObject selectedObj;
    NodePrimitive curObj;
    Transform sceneNode;
    //GameObject selectedAxis;
    private const float kPixelToDegree = 0.5f;
    Quaternion originRotation;
    Vector3 mousePosition;
    void ProcessMouseEvents()
    {

        Vector3 hitPoint;
        if (Input.GetMouseButtonDown(0)) // Click event
        {
            Debug.Log("left button down");
            if (MouseSelectObjectAt(out selectedObj, out hitPoint, LayerMask.GetMask("Default")))
            {
                Debug.Log("mouse on = " + selectedObj);
                if (selectedObj.GetComponent<NodePrimitive>() != null)
                {
                    curObj = selectedObj.GetComponent<NodePrimitive>();
                    curObj.SetColor(Color.yellow);
                    Debug.Log("cur = " + curObj);
                    mousePosition = Input.mousePosition;
                    sceneNode = curObj.transform.parent.gameObject.transform.parent.gameObject.transform;
                    //originRotation = curObj.transform.parent.gameObject.transform.parent.gameObject.transform.localRotation;
                }
            }
        }
        if (Input.GetMouseButton(0) && curObj != null) // Mouse Drag
        {
            //Debug.Log("left button held");
        
            Vector3 newMousePosition = Input.mousePosition;
                        
            float deltaX = (newMousePosition - mousePosition).x * kPixelToDegree;  // newX - origX;
            float deltaY = (newMousePosition - mousePosition).y * kPixelToDegree; // newY - origY;
            //Debug.Log("holding = " + selectedObj.name);
            if(curObj.gameObject.name == "Base")
            {
                ComputeMove(deltaX, deltaY);
            }
            else
            {
                ComputeRotation(deltaX, deltaY);
            }    
            
            mousePosition = newMousePosition;
            
                    
        }
        if (Input.GetMouseButtonUp(0)) // Mouse up
        {
            //Debug.Log("left button release");
            if (curObj != null)
            {
                curObj.SetOriginColor();
                curObj = null;
            }
        }

    }

    

    bool MouseSelectObjectAt(out GameObject g, out Vector3 p, int layerMask)
    {
        RaycastHit hitInfo = new RaycastHit();
        bool hit = Physics.Raycast(MainCamera.ScreenPointToRay(Input.mousePosition), out hitInfo, Mathf.Infinity, layerMask);
        // Debug.Log("MouseSelect:" + layerMask + " Hit=" + hit);
        if (hit)
        {
            g = hitInfo.transform.gameObject;
            p = hitInfo.point;
        }
        else
        {
            g = null;
            p = Vector3.zero;
        }
        return hit;
    }
    void ComputeMove(float deltax, float deltay)
    {
        //Debug.Log("vertex = " + selectedVertex);
        if (curObj != null && sceneNode != null)
        {
            //GameObject sceneNode = curObj.transform.parent.gameObject.transform.parent.gameObject;
            Debug.Log("scenenode = " + sceneNode);
            sceneNode.localPosition += sceneNode.right * deltax * Time.deltaTime * 0.3f;
            sceneNode.localPosition += sceneNode.forward * deltay * Time.deltaTime * 0.3f;
            //Xfrom.transform.localPosition = selectedVertex.transform.localPosition;
        }
    }

    void ComputeRotation(float deltax, float deltay)
    {
        //Debug.Log("vertex = " + selectedVertex);
        if (curObj != null && sceneNode != null)
        {
            
            Debug.Log("scenenode = " + sceneNode);
            Quaternion up = Quaternion.AngleAxis(deltay, Vector3.right);
            sceneNode.localRotation *= up;
            Quaternion side = Quaternion.AngleAxis(deltax, -Vector3.forward);
            sceneNode.transform.localRotation *= side;
            //sceneNode.transform.localPosition += sceneNode.transform.right * deltax * Time.deltaTime * 0.3f;
            //sceneNode.transform.localPosition += sceneNode.transform.forward * deltay * Time.deltaTime * 0.3f;
            //Xfrom.transform.localPosition = selectedVertex.transform.localPosition;
        }
    }

    //private void RotateCameraPosition(ref Quaternion q)
    //{
    //    Matrix4x4 r = Matrix4x4.TRS(Vector3.zero, q, Vector3.one);
    //    Matrix4x4 invP = Matrix4x4.TRS(-LookAt.localPosition, Quaternion.identity, Vector3.one);
    //    Matrix4x4 m = invP.inverse * r * invP;

    //    Vector3 newCameraPos = m.MultiplyPoint(transform.localPosition);
    //    if (Mathf.Abs(Vector3.Dot(newCameraPos.normalized, Vector3.up)) < 0.985)
    //    {
    //        transform.localPosition = newCameraPos;

    //        // First way:
    //        // transform.LookAt(LookAt);
    //        // Second way:
    //        // Vector3 v = (LookAt.localPosition - transform.localPosition).normalized;
    //        // transform.localRotation = Quaternion.LookRotation(v, Vector3.up);
    //        // Third way: do everything ourselve!
    //        Vector3 v = (LookAt.localPosition - transform.localPosition).normalized;
    //        Vector3 w = Vector3.Cross(v, transform.up).normalized;
    //        Vector3 u = Vector3.Cross(w, v).normalized;
    //        // INTERESTING: 
    //        //    chaning the following directions must be done in specific sequence!
    //        //    E.g., NONE of the following order works: 
    //        //          Forward, Up, Right 
    //        //          Forward, Right, Up 
    //        //          Right, Forward, Up 
    //        //          Up, Forward, Right 
    //        //
    //        //   Forward-Vector MUST BE set LAST!!: both of the following works!
    //        //          Right, Up, Forward
    //        //          Up, Right, Forward
    //        transform.up = u;
    //        transform.right = w;
    //        transform.forward = v;
    //    }
    //}
}
