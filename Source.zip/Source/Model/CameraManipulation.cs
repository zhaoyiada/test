﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManipulation : MonoBehaviour {

    // public Camera camera;

    public enum LookAtCompute {
        QuatLookRotation = 0,
        TransformLookAt = 1
    };

    public Transform LookAtPosition = null;
    public LookAtCompute ComputeMode = LookAtCompute.QuatLookRotation;
    //public bool OrbitHorizontal = false, OrbitVertical = false;
    float zoomSpeed = 8.0f;
    Vector3 origLocation;

    // Use this for initialization
    void Start () {
        mousePosition = Input.mousePosition;
        Debug.Assert(LookAtPosition != null);
        origLocation = transform.localPosition;
        Debug.Log("origlocation = " + transform.localPosition);
	}

    private Vector3 mousePosition; // = Input.mousePosition;

    // Update is called once per frame
    void Update () {

        if (Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt))
        {
            //zooming 
            float scroll = Input.GetAxis("Mouse ScrollWheel");

            transform.localPosition += (LookAtPosition.localPosition - transform.localPosition).normalized * scroll * zoomSpeed;

            //left mouse button control tumble
            if (Input.GetMouseButtonDown(0))
            {
                // origX = Input.mousePosition.x; // Input.GetAxis("Mouse X");
                // origY = Input.mousePosition.y; // Input.GetAxis("Mouse Y");
            }
            if (Input.GetMouseButton(0))
            {
                // float newX = Input.mousePosition.x; // Input.GetAxis("Mouse X");
                // float newY = Input.mousePosition.y; // Input.GetAxis("Mouse Y");

                // Debug.Log("new x" + newX);

                float rotationX = Input.GetAxis("Mouse X"); // newX - origX;
                float rotationY = Input.GetAxis("Mouse Y"); // newY - origY;
                // Debug.Log("rotationX = " + rotationX);
                // Debug.Log("rotationY = " + rotationY);
                ComputeHorizontalOrbit(rotationX);
                ComputeVerticalOrbit(rotationY);

                // origX = newX;
                // origY = newY;
            }
            //right mouse button control track
            if (Input.GetMouseButtonDown(1))
            {
                // origX = Input.GetAxis("Mouse X");
                // origY = Input.GetAxis("Mouse Y");

                //cameraPos = new Vector3();
                //cameraPos.x = transform.position.x;
                //cameraPos.y = transform.position.y;
                //cameraPos.z = transform.position.z;
                mousePosition = Input.mousePosition;
            }
            if (Input.GetMouseButton(1))
            {
                //Debug.Log("new = " + Input.GetAxis("Mouse X"));
                //Debug.Log("org = " + origX);

                // float newX = Input.GetAxis("Mouse X");
                // float newY = Input.GetAxis("Mouse Y");

                Vector3 newMousePosition = Input.mousePosition;

                /*Vector3 delta = GetComponent<Camera>().ScreenToWorldPoint(newMousePosition)
                    - GetComponent<Camera>().ScreenToWorldPoint(mousePosition);

                Debug.Log("newMousePosition = " + GetComponent<Camera>().ScreenToWorldPoint(newMousePosition));
                Debug.Log("mousePosition = " + GetComponent<Camera>().ScreenToWorldPoint(mousePosition));
                Debug.Log("delta = " + delta);*/

                float rotationX = (newMousePosition - mousePosition).x; // Input.GetAxis("Mouse X") ; // newX - origX;
                float rotationY = (newMousePosition - mousePosition).y; // Input.GetAxis("Mouse Y") ; // newY - origY;
                // Debug.Log("rotationX = " + rotationX);
                //Debug.Log("rotationY = " + rotationY);
                TrackHorizontal(rotationX);
                TrackVertical(rotationY);

                // origX = newX;
                // origY = newY;

                mousePosition = newMousePosition;
            }


        }
    }

    private Vector3 cameraPos;

    const float RotateDelta = 10f / 60;  // about 10-degress per second
    float Direction = 1f;
    void ComputeHorizontalOrbit(float x)
    {

        // orbit with respect to the transform.right axis

        // 1. Rotation of the viewing direction by right axis
        Quaternion q = Quaternion.AngleAxis(Direction * x, transform.up);

        // 2. we need to rotate the camera position
        Matrix4x4 r = Matrix4x4.TRS(Vector3.zero, q, Vector3.one);
        Matrix4x4 invP = Matrix4x4.TRS(-LookAtPosition.localPosition, Quaternion.identity, Vector3.one);
        r = invP.inverse * r * invP;
        Vector3 newCameraPos = r.MultiplyPoint(transform.localPosition);
        transform.localPosition = newCameraPos;
        transform.LookAt(LookAtPosition);
        
        //if (Mathf.Abs(Vector3.Dot(newCameraPos.normalized, Vector3.up)) > 0.7071f) // this is about 45-degrees
        //{
        //    Direction *= -1f;
        //}

    }
    void ComputeVerticalOrbit(float y)
    {
        // orbit with respect to the transform.right axis

        // 1. Rotation of the viewing direction by right axis
        Quaternion q = Quaternion.AngleAxis(-Direction * y, transform.right);

        // 2. we need to rotate the camera position
        Matrix4x4 r = Matrix4x4.TRS(Vector3.zero, q, Vector3.one);
        Matrix4x4 invP = Matrix4x4.TRS(-LookAtPosition.localPosition, Quaternion.identity, Vector3.one);
        r = invP.inverse * r * invP;
        Vector3 newCameraPos = r.MultiplyPoint(transform.localPosition);
        //transform.localPosition = newCameraPos;
        //transform.LookAt(LookAtPosition);

        // Debug.Log(Vector3.Dot(newCameraPos.normalized, Vector3.up));

        // Debug.Log("y = " + y);

        if (Mathf.Abs(Vector3.Dot(newCameraPos.normalized, Vector3.up)) < 0.9997f) // this is about 45-degrees
        {
            // Debug.Log("p = " + newCameraPos);
            transform.localPosition = newCameraPos;
            transform.LookAt(LookAtPosition);
        }
    }
    void TrackHorizontal(float x)
    {
        //Vector3 V = LookAtPosition.localPosition - transform.localPosition;
        //Vector3 W = Vector3.Cross(-V, transform.up);
        //transform.localPosition += 0.005f * x * W;
        //LookAtPosition.localPosition += 0.005f * x * W;

        Matrix4x4 m = Matrix4x4.TRS(Vector3.zero, transform.rotation, Vector3.one);
        Vector3 p = new Vector3(-x, 0.0f, 0.0f);
        // p = GetComponent<Camera>().ScreenToWorldPoint(p);
        p = m.MultiplyPoint(p);
        p = 0.1f * p;
        transform.localPosition += p;
        LookAtPosition.localPosition += p;
    }
    void TrackVertical(float y)
    {
        //Vector3 V = LookAtPosition.localPosition - transform.localPosition;
        //Vector3 W = Vector3.Cross(-V, transform.up);
        //Vector3 U = Vector3.Cross(W, -V);
        //transform.localPosition += 0.005f * y * Vector3.up;
        //LookAtPosition.localPosition += 0.005f * y * Vector3.up;

        Matrix4x4 m = Matrix4x4.TRS(Vector3.zero, transform.rotation, Vector3.one);
        Vector3 p = new Vector3(0.0f, -y, 0.0f);
        // p = GetComponent<Camera>().ScreenToWorldPoint(p);
        p = m.MultiplyPoint(p);
        p = 0.1f * p;
        transform.localPosition += p;
        LookAtPosition.localPosition += p;
    }
    public void ReSet()
    {
        transform.localPosition = origLocation;
        transform.LookAt(LookAtPosition);
    }
}
