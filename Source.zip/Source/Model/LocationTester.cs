﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocationTester : MonoBehaviour {
	// Use this for initialization
	void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {

    }

    public void set(Matrix4x4 m, Vector3 NodeOrigin)//Matrix4x4 m, 
    {
        // now decomposite and get each components
        transform.localPosition = m.GetColumn(3);
        Vector3 x = m.GetColumn(0);
        Vector3 y = m.GetColumn(1);
        Vector3 z = m.GetColumn(2);
        Vector3 size = new Vector3(x.magnitude, y.magnitude, z.magnitude);
        transform.localScale = size;
        transform.localRotation = m.rotation;
    }
}
