﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallCamera : MonoBehaviour {
    public NodePrimitive head;
    //private Vector3 refPos = new Vector3(0, 0, 0);
	// Use this for initialization
	void Start () {
        Debug.Assert(head != null);

	}
	
	// Update is called once per frame
	void Update () {
        //get my position from head
        Matrix4x4 parent = head.getMyTransform();
        //Matrix4x4 refPosT = Matrix4x4.Translate(refPos);
        Matrix4x4 m = parent;

        // now decomposite and get each components
        transform.localPosition = m.GetColumn(3);
        Vector3 x = m.GetColumn(0);
        Vector3 y = m.GetColumn(1);
        Vector3 z = m.GetColumn(2);
        transform.localPosition += y;
        //Vector3 size = new Vector3(x.magnitude, y.magnitude, z.magnitude);
        //transform.localScale = size; //no scale for camera

        Vector3 V = y;//head.transform.localPosition - transform.localPosition;
        Vector3 W = Vector3.Cross(-V, transform.up);
        Vector3 U = Vector3.Cross(W, -V);
        transform.localRotation = Quaternion.LookRotation(V, U);
        
	}
}
