﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateObj : MonoBehaviour {
    int kNumSteps = 100;
    float delta;
    int count = 0;
    bool firstTime = true;
    // Use this for initialization
    void Start () {
        float theta = Mathf.Acos(-1) * Mathf.Rad2Deg; // we know v1 and v2 are normalized
        delta = theta / (float)kNumSteps;
    }
	
	// Update is called once per frame
	void Update () {

        count++;
        if (firstTime && count == kNumSteps / 2)
        {
            delta = -delta;
            count = 0;
            firstTime = false;
        }
        if (count == kNumSteps)
        {
            delta = -delta;
            count = 0;
        }

        Quaternion q = Quaternion.AngleAxis(delta, Vector3.forward);
        transform.localRotation *= q;
        //Debug.Log(transform.localRotation);
    }
}
