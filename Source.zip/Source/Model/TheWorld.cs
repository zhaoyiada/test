﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TheWorld : MonoBehaviour  {

    public SceneNode TheRoot;
    public Transform myTree;
    private NodePrimitive mSelected;
    private void Start()
    {
        //myTree.GetComponent<>
    }

    private void Update()
    {
        Matrix4x4 i = Matrix4x4.identity;
        TheRoot.CompositeXform(ref i);
    }
}
