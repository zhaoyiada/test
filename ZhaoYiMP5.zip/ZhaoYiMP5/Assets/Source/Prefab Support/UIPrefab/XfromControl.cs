﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class XfromControl : MonoBehaviour
{

    public SliderWithEcho X, Y;
    public MyMesh myMesh;

    // Use this for initialization
    void Start()
    {
        Debug.Assert(myMesh != null);
        Debug.Assert(X != null);
        X.SetSliderListener(XValueChanged);
        Y.SetSliderListener(YValueChanged);
        //X.SetSliderValue(5);
        SetRange();


    }

    void Update()
    {

    }

    //---------------------------------------------------------------------------------
    // Initialize slider bars to specific function
    void SetRange()
    {
        float p = ReadObjectXfrom();
        //mPreviousSliderValues = p;
        X.InitSliderRange(2, 20, p);
        p = ReadObjectYfrom();
        Y.InitSliderRange(2, 20, p);
        //Z.InitSliderRange(-30, 30, p.z);

    }
    //---------------------------------------------------------------------------------

    //---------------------------------------------------------------------------------
    // resopond to sldier bar value changes
    void XValueChanged(float v)
    {
        float p = ReadObjectXfrom();
        X.TheEcho.text = (p).ToString();
        myMesh.SetRow((int)p);
    }

    void YValueChanged(float v)
    {
        float p = ReadObjectYfrom();
        Y.TheEcho.text = (p).ToString();
        myMesh.SetCol((int)p);
    }
    //---------------------------------------------------------------------------------

    private float ReadObjectXfrom()
    {
        float p;
        p = X.GetSliderValue();
        //Debug.Log("p = " + p);
        //p.y = Y.GetSliderValue();
        //p.z = Z.GetSliderValue();
        return p;
    }

    private float ReadObjectYfrom()
    {
        float p;
        p = Y.GetSliderValue();
        //Debug.Log("p = " + p);
        //p.y = Y.GetSliderValue();
        //p.z = Z.GetSliderValue();
        return p;
    }
}
